#include "Sever.h"

#define DEBUG
using namespace std;

int main(int argc, char *argv[]){
	Sever s;
	s.work();
	return 0;
}